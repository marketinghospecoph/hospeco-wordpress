<?php
/**
 * The template for displaying archive pages
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package 'Clerina'
 */

get_header();
?>

<div id="primary" class="content-area col-md-12 col-sm-12 col-xs-12">
    <main id="main" class="site-main row" role="main">
		<?php do_action( 'clerina_portfolio_before_content' ); ?>
		<?php if ( have_posts() ) : ?>
            <div id="clerina_portfolio_grid">
				<?php
				/* Start the Loop */
				while ( have_posts() ) :
					the_post();
					/*
					 * Include the Post-Type-specific template for the content.
					 * If you want to override this in a child theme, then include a file
					 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
					 */
					get_template_part( 'template-parts/content', 'portfolio' );
				endwhile;

				?>
            </div>
			<?php clerina_pagination();?>
		<?php
		else :
			get_template_part( 'template-parts/content', 'none' );
		endif;
		?>

    </main><!-- #main -->
</div><!-- #primary -->
<?php get_footer(); ?>
