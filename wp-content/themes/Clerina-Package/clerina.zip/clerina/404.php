<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package 'Clerina'
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php esc_html_e( '404', 'clerina' ); ?></h1>
					<p class="line-1"><?php esc_html_e( 'Ooops! That page doesn&rsquo;t exist!',  'clerina' ); ?></p>
					<p class="line-2"><?php esc_html_e( 'You might searching our site, or starting at our home page',  'clerina' ); ?></p>
				</header><!-- .page-header -->

				<div class="page-content">
					<a href="<?php echo esc_url( home_url( '/' ) ) ?>"><?php esc_html_e( 'Back to Home Page', 'clerina' ) ?></a>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
